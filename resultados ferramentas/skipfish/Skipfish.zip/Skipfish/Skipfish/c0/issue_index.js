var issue = [
  { 'severity': 0, 'type': 10505, 'sid': '0', 'extra': 'nome', 'fetched': true, 'code': 200, 'len': 29175, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'UTF-8', 'dir': 'i0' },
  { 'severity': 0, 'type': 10505, 'sid': '0', 'extra': 'senha', 'fetched': true, 'code': 200, 'len': 29175, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'UTF-8', 'dir': 'i1' },
  { 'severity': 0, 'type': 10404, 'sid': '0', 'extra': 'Directory listing', 'fetched': true, 'code': 200, 'len': 920, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'ISO-8859-1', 'dir': 'i2' },
  { 'severity': 0, 'type': 10205, 'sid': '0', 'extra': '', 'fetched': true, 'code': 404, 'len': 1150, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'dir': 'i3' },
  { 'severity': 0, 'type': 10202, 'sid': '0', 'extra': 'Apache/2.4.28 (Unix) OpenSSL/1.0.2l PHP/7.1.10 mod_perl/2.0.8-dev Perl/v5.16.3', 'fetched': true, 'code': 200, 'len': 920, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'ISO-8859-1', 'dir': 'i4' }
];
