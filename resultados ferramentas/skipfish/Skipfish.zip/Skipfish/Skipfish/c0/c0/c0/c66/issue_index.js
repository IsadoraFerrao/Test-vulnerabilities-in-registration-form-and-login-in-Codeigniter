var issue = [
  { 'severity': 0, 'type': 10204, 'sid': '0', 'extra': 'X-Powered-By', 'fetched': true, 'code': 404, 'len': 357, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'dir': 'i0' }
];
