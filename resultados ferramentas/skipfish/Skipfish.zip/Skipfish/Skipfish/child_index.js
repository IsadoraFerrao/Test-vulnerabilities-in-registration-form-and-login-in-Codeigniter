var child = [
  { 'dupe': false, 'type': 2, 'name': 'http://127.0.0.1/', 'dir': 'c0', 'linked': 2, 'url': 'http://127.0.0.1/', 'fetched': true, 'code': 200, 'len': 920, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'ISO-8859-1', 'missing': false, 'csens': true, 'child_cnt': 94, 'issue_cnt': [ 36, 0, 4, 1, 0 ], 'sig': 0x765855a9 }
];
