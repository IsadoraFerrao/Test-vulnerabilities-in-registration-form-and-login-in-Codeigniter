var sf_version = '2.10b';
var scan_date  = 'Sun Apr 29 14:23:40 2018';
var scan_seed  = '0xfe4ac79d';
var scan_ms    = 337092;
