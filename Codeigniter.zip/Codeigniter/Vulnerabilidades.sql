-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 25, 2018 at 08:08 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Vulnerabilidades`
--

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `nome` varchar(500) NOT NULL,
  `senha` varchar(500) NOT NULL,
  `nivel` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`nome`, `senha`, `nivel`) VALUES
('efef', '', '0'),
('effe', '202cb962ac59075b964b07152d234b70', '0'),
('fef', 'dda76af2974450b722760e636225e1fd', '0'),
('rrggr', '5828bb6f63885517f2710fe2371a9af6', '0'),
('kokoe', 'e5ea9b6d71086dfef3a15f726abcc5bf', '0'),
('kefkife', '150fd0e9a9c115e5061c73d7befb7a53', '0'),
('efe', '29def653e63e645d246eb84220e38d71', '0'),
('dccd', '633de4b0c14ca52ea2432a3c8a5c4c31', '0'),
('feffe', '81b480ac3b458cf7c6aa88552ebeb0a0', '0'),
('wddw', '2e838f2f2652dab5c976381d58463ba6', '0'),
('efef', '81b480ac3b458cf7c6aa88552ebeb0a0', '0');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
