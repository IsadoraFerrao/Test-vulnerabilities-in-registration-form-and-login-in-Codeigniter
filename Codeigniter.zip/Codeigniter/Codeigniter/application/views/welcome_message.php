<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.css')?>">
	<style type="text/css">
    

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
</head>
<body>

<div id="container">


    <?php if($this->session->flashdata('danger')):?>
    <p class="alert alert-danger"><?= $this->session->flashdata("danger")?></p>
    
    <?php endif?>

	<h1> TCC ISADORA FERRÃO - SISTEMA DE TESTES </h1>
   <!-- <?php echo form_open('Usuarios/novo');
        echo form_label('Nome');
        echo form_input('nome');
        echo form_label('Senha');    
        echo form_password('senha');
        $data = array(
        'content'=> 'Cadastrar',
        'type'=> 'submit'
        );
        echo form_button($data);
    echo form_close(); ?>-->

    <form action="Usuarios/novo" method="post">
        <input type="text" name="nome" value="nome">
        <input type="password" name="senha" value="senha">
        <input type="submit" value="Cadastrar">
    </form>

	<h1> Login </h1>
    <?php echo form_open('login/autenticar');
        echo form_label('Nome');
        echo form_input('nome');
        echo form_label('Senha');    
        echo form_password('senha');
        $data = array(
        'content'=> 'Login',
        'type'=> 'submit',
        'uri'=> 'jose',
        );
        echo form_button($data);
    echo form_close(); ?>

 <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d3462.587503728983!2d-55.77078578489995!3d-29.789566926428762!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1spt-BR!2sbr!4v1508864877378" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
    
</div>

	<h1> Usuários cadastrados</h1>
    <table class="table">
        <tr>
            <th>Nome</th>
        </tr>
        <?php foreach ($usuarios as $usuario) : ?>
        <tr>
            <td><?= $usuario['nome'] ?></td>
        </tr>
        <?php endforeach ?>
    </table>




</body>
</html>
