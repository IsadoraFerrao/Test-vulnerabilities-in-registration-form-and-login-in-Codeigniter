<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario_model extends CI_Model {

	public function buscaTodos()
	{
        return $this->db->get('usuarios')->result_array();
	}
}
