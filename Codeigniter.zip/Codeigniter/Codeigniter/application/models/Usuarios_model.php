<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuarios_model extends CI_Model {

	public function salva($usuario)
	{
        $this->db->insert('usuarios', $usuario);
	}
    public function logarUsuarios($nome, $senha){
        $this->db->where('nome', $nome);
        $this->db->where('senha', $senha);
        $this->db->where('nivel', 1);
        $usuario = $this->db->get('usuarios')->row_array();
        return $usuario;
    }
}
