<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuarios extends CI_Controller {

	public function novo($nome = NULL)	{
        $usuario = array(
            'nome' => $this->input->post('nome'),      
            'senha' => md5($this->input->post('senha'))       
        );
		$this->load->model('usuarios_model');
        $this->usuarios_model->salva($usuario);  
        $this->load->view('logado');
        echo $nome;

	}
}
