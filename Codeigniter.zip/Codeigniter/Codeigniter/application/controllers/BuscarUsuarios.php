<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BuscarUsuarios extends CI_Controller {

	public function index()
	{
        $this->load->model('usuario_model');
        $lista = $this->usuario_model->buscaTodos();
        $dados = array('usuarios' => $lista);
        $this->load->view('welcome_message', $dados);
	}

}
